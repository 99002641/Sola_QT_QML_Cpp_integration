# Examples

* example1 - Rectangle
* example2 - Text
* example3 - Text within Rectangle
* example4 - Multiple elements
* example5 - anchors - top, bottom, left, right
* exmaple6 - anchors.centerIn
* example7 - mouse area
* example8 - Text Input
* example9 - Text Edit
* example10 - Timer
* example11 - Image
* example12 - Keyboard
